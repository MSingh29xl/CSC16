#include <iostream>
using namespace std;

class MyClass {
public:
 int getData();
 void setData(int data);
 int myFastFunc() {
 return 1 + 1;
 }

private: 
int data;
}; 

int MyClass::getData() {
 return data;
}

void MyClass::setData(int data) {
 if (data >= 10 || data <= 50) {
   this -> data = data;
  }
  else {
   cout<<"Data"<<data<<" outside range"<<endl;
 }
}

ostream &operator<<(ostream &out, MyClass &mc) {
 out<<mc.getData()<<endl;
 return out;
}

istream &operator>>(istream &in, MyClass &mc) {
 int data;
 in>>data;
 mc.setData(data);
 return in;
}

bool operator<(MyClass &mc, MyClass&mc2) {
 return mc.getData()<mc2.getData();
}

int main() {

 MyClass mc;
 mc.setData(100);
 mc.setData(50);
 cout<<mc.getData()<<endl;
 cout<<mc<<endl;
 cout<<"Please enter data"<<endl; 
 cin>>mc;
 cout<<mc; 
 MyClass mc2;
 mc2.setData(27);
 if(mc<mc2) {
 cout<<"mc smaller than mc2"<<endl;
 }
 else {
 cout<<"mc bigger than mc2"<<endl;
 }

 return 0;
}
