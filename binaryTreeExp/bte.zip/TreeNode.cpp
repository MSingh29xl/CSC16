#include "TreeNode.h"

TreeNode::TreeNode(DataType data, TreeNode *left, TreeNode *right)
{
  this->data = data;
  this->left = left;
  this->right= right;
}
