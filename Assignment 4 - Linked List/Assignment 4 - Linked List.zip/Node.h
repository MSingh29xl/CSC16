#ifndef NODE_H
#define NODE_H
typedef int DataType;

class Node {

public:
 DataType data;
 Node *next;
 

};


#endif //NODE_H
