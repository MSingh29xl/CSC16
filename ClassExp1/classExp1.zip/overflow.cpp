# include <iostream>
using namespace std;

int main(){
cout<<"size of int is:"<<sizeof(int);
cout<<"size of long is:"<<sizeof(long);
long number = 1;
for(int i=0; i<=65; i++){
cout<<number<<endl;
number = number * 2;
 }
}
